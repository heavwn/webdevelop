const calculadora = require('../calculadora/calculadora');

exports.calcular = (req, res) => {
  const { num1, num2, operador } = req.body;

  if (isNaN(num1) || isNaN(num2)) {
    res.redirect('/?error=Valores não numéricos fornecidos');
    return;
  }

  const resultado = calculadora.calcular(Number(num1), Number(num2), operador);
  const nomeOperador = calculadora.getNomeOperador(operador);

  res.render('resultado', { num1, num2, operador: nomeOperador, resultado });
};
