const express = require('express');
const path = require('path');
const app = express();
const port = 8080;

const calculadoraRoutes = require('./src/routes/calculadoraRoutes');

app.use(express.urlencoded({ extended: true }));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src/views'));

app.use('/calculadora', calculadoraRoutes);

app.get('/', (req, res) => {
  res.render('index', { error: null });
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});